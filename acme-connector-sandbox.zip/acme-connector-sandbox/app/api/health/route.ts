import { NextResponse } from "next/server";

// Liveness check for the sandbox itself (not the connectors service).
export async function GET() {
  return NextResponse.json({
    status: "ok",
    service: "acme-connector-sandbox",
    time: new Date().toISOString(),
  });
}
