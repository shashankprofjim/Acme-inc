// Thin server-side wrapper around the connectors service.
// Reads config from env so nothing sensitive reaches the browser.
// This is intentionally minimal — adjust paths to match your real API.

const BASE_URL = process.env.CONNECTOR_SERVICE_URL ?? "http://localhost:8080";
const TOKEN = process.env.CONNECTOR_SERVICE_TOKEN ?? "";

export type ConnectorRequestOptions = {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  // Extra headers merged over the defaults.
  headers?: Record<string, string>;
};

export type ConnectorResponse<T = unknown> = {
  ok: boolean;
  status: number;
  data: T | null;
  error?: string;
};

/**
 * Call an endpoint on the connectors service.
 * `path` is joined to CONNECTOR_SERVICE_URL, e.g. request("/connectors").
 */
export async function request<T = unknown>(
  path: string,
  options: ConnectorRequestOptions = {},
): Promise<ConnectorResponse<T>> {
  const url = `${BASE_URL.replace(/\/$/, "")}${path.startsWith("/") ? path : `/${path}`}`;

  const headers: Record<string, string> = {
    "content-type": "application/json",
    ...(TOKEN ? { authorization: `Bearer ${TOKEN}` } : {}),
    ...options.headers,
  };

  try {
    const res = await fetch(url, {
      method: options.method ?? "GET",
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
      // Sandbox: always hit the live service, never a cache.
      cache: "no-store",
    });

    const text = await res.text();
    let data: T | null = null;
    if (text) {
      try {
        data = JSON.parse(text) as T;
      } catch {
        // Non-JSON response — hand back the raw text under a known shape.
        data = text as unknown as T;
      }
    }

    return { ok: res.ok, status: res.status, data };
  } catch (err) {
    return {
      ok: false,
      status: 0,
      data: null,
      error: err instanceof Error ? err.message : "Unknown network error",
    };
  }
}

export const connectorClient = { request, baseUrl: BASE_URL };
